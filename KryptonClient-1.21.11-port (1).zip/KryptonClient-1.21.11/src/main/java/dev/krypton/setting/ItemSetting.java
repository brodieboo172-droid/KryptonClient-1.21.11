package dev.krypton.setting;
import net.minecraft.item.Item; import java.util.*;
public class ItemSetting extends Setting {
    private Item value; private final List<Item> allowed;
    public ItemSetting(String n,Item v){this(n,v,List.of());}
    public ItemSetting(String n,Item v,List<Item> allowed){this.value=v;this.allowed=allowed;}
    public Item getValue(){return value;}
    public ItemSetting setValue(Item v){value=v;return this;}
}
