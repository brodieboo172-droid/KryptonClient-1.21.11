package dev.krypton.setting;
public class NumberSetting extends Setting {
    private final double min,max,step; private double value;
    public NumberSetting(String n,double min,double max,double value,double step){this.min=min;this.max=max;this.value=value;this.step=step;}
    public int getInt(){return (int)Math.round(value);}
    public double getDouble(){return value;}
    public NumberSetting setValue(double v){value=Math.max(min,Math.min(max,v)); return this;}
    @Override public NumberSetting setDescription(String s){super.setDescription(s); return this;}
    @Override public NumberSetting visibleWhen(java.util.function.BooleanSupplier b){super.visibleWhen(b); return this;}
}
