package dev.krypton.setting;
import java.util.function.BooleanSupplier;
public class Setting {
    private String description=""; private BooleanSupplier visible=()->true;
    public Setting setDescription(String s){description=s; return this;}
    public Setting doNotSave(){return this;}
    public Setting visibleWhen(BooleanSupplier b){visible=b; return this;}
    public boolean isVisible(){return visible.getAsBoolean();}
}
