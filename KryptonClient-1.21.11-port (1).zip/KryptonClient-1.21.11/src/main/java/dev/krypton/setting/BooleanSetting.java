package dev.krypton.setting;
public class BooleanSetting extends Setting {
    private boolean value;
    public BooleanSetting(String n, boolean v){value=v;}
    public boolean getValue(){return value;}
    public BooleanSetting setValue(boolean v){value=v; return this;}
    @Override public BooleanSetting setDescription(String s){super.setDescription(s); return this;}
    @Override public BooleanSetting doNotSave(){super.doNotSave(); return this;}
    @Override public BooleanSetting visibleWhen(java.util.function.BooleanSupplier b){super.visibleWhen(b); return this;}
}
