package dev.krypton.setting;
public class StringSetting extends Setting {
    private String value;
    public StringSetting(String n,String v){value=v;}
    public String getValue(){return value;}
    public StringSetting setValue(String v){value=v; return this;}
    @Override public StringSetting setDescription(String s){super.setDescription(s); return this;}
    @Override public StringSetting doNotSave(){super.doNotSave(); return this;}
    @Override public StringSetting visibleWhen(java.util.function.BooleanSupplier b){super.visibleWhen(b); return this;}
}
