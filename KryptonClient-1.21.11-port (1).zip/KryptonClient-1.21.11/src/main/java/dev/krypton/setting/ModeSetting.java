package dev.krypton.setting;
public class ModeSetting<T extends Enum<T>> extends Setting {
    private T value; private final Class<T> type;
    public ModeSetting(String n,T v,Class<T> type){value=v;this.type=type;}
    public T getValue(){return value;}
    public boolean is(T v){return value==v;}
    public ModeSetting<T> setValue(T v){value=v;return this;}
    @Override public ModeSetting<T> setDescription(String s){super.setDescription(s);return this;}
    @Override public ModeSetting<T> visibleWhen(java.util.function.BooleanSupplier b){super.visibleWhen(b);return this;}
}
