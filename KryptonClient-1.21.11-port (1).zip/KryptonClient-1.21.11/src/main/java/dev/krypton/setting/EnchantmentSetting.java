package dev.krypton.setting;
import java.util.*;
public class EnchantmentSetting extends Setting { private final List<EnchantmentOption> values=new ArrayList<>(); public EnchantmentSetting(String n){} public List<EnchantmentOption> getValues(){return values;} }
