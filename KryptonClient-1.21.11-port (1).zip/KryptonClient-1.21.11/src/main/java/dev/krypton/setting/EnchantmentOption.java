package dev.krypton.setting;
public class EnchantmentOption { private final String searchText; public EnchantmentOption(String s){searchText=s;} public String getSearchText(){return searchText;} }
