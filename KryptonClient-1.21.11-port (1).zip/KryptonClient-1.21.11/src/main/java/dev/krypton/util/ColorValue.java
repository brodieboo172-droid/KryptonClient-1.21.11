package dev.krypton.util;
public final class ColorValue {
    public static final ColorValue YELLOW = new ColorValue(255,255,0,255);
    public final int r,g,b,a;
    public ColorValue(int r,int g,int b,int a){this.r=r;this.g=g;this.b=b;this.a=a;}
    public ColorValue(float r,float g,float b,float a){this(Math.round(r*255),Math.round(g*255),Math.round(b*255),Math.round(a*255));}
}
