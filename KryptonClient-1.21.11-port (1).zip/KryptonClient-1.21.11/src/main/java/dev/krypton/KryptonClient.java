package dev.krypton;

import dev.krypton.event.*;
import dev.krypton.module.Module;
import dev.krypton.module.KrModules.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import java.lang.reflect.Method;
import java.util.*;

public final class KryptonClient implements ClientModInitializer {
    public static final List<Module> MODULES = new ArrayList<>();
    private final List<KeyBinding> keys = new ArrayList<>();
    private boolean hadWorld;
    private int tick;

    @Override public void onInitializeClient() {
        MODULES.addAll(List.of(
            new AntiTrap(), new AuctionSniper(), new AutoSell(), new AutoShop(),
            new HoleESP(), new LightFinder(), new SeedChunkFinder(),
            new SusChunkFinder(), new SuspiciousESP()
        ));
        int key = GLFW.GLFW_KEY_F6;
        for (Module m : MODULES) {
            KeyBinding kb = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.krypton." + m.name.toLowerCase(Locale.ROOT).replace(' ','_'),
                InputUtil.Type.KEYSYM, key++, "category.krypton"
            ));
            keys.add(kb);
        }
        ClientTickEvents.END_CLIENT_TICK.register(client -> tick());
        WorldRenderEvents.END_MAIN.register(ctx -> render(ctx));
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> fire(new GameJoinEvent()));
    }

    private void tick() {
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        for (Module m : MODULES) m.refreshRefs();
        for (int i=0;i<keys.size();i++) {
            while (keys.get(i).wasPressed()) MODULES.get(i).toggle();
        }
        boolean world = mc.world != null;
        if (world && !hadWorld) fire(new GameJoinEvent());
        hadWorld = world;
        if (world) {
            fire(new WorldTickEvent());
            if ((tick++ % 40) == 0) {
                int r = Math.min(mc.options.getClampedViewDistance(), 8);
                if (mc.player != null) {
                    int cx=mc.player.getChunkPos().x, cz=mc.player.getChunkPos().z;
                    for(int x=cx-r;x<=cx+r;x++) for(int z=cz-r;z<=cz+r;z++)
                        fire(new ChunkDataEvent(x,z));
                }
            }
        }
        gpz.refresh();
    }

    private void render(net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext ctx) {
        if (net.minecraft.client.MinecraftClient.getInstance().world == null) return;
        WorldRenderEvent e = new WorldRenderEvent(ctx);
        fire(e);
    }

    private void fire(Object event) {
        for (Module m : MODULES) {
            if (!m.isEnabled()) continue;
            m.refreshRefs();
            for (Method method : m.getClass().getMethods()) {
                if (!method.isAnnotationPresent(Subscribe.class) || method.getParameterCount()!=1) continue;
                if (!method.getParameterTypes()[0].isAssignableFrom(event.getClass())) continue;
                try { method.invoke(m,event); } catch (Throwable t) { /* one broken module must not kill the client */ }
            }
        }
    }
}
