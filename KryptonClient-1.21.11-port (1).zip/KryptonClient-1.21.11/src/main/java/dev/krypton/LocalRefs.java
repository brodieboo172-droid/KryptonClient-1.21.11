package dev.krypton;
import net.minecraft.client.MinecraftClient; import net.minecraft.client.network.ClientPlayerEntity; import net.minecraft.client.world.ClientWorld; import net.minecraft.client.option.GameOptions;
public final class LocalRefs { private final MinecraftClient mc=MinecraftClient.getInstance(); public ClientPlayerEntity player(){return mc.player;} public ClientWorld world(){return mc.world;} public ClientPlayerEntity player; public ClientWorld world; public GameOptions options; public void refresh(){player=mc.player;world=mc.world;options=mc.options;} }
