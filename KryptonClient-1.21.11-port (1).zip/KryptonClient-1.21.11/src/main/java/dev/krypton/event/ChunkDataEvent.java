package dev.krypton.event;
public final class ChunkDataEvent { public final Packet packet; public ChunkDataEvent(int x,int z){packet=new Packet(x,z);} public static final class Packet { private final int x,z; public Packet(int x,int z){this.x=x;this.z=z;} public int getChunkX(){return x;} public int getChunkZ(){return z;} } }
