package dev.krypton.event;
import net.minecraft.util.math.BlockPos; import net.minecraft.block.BlockState;
public final class BlockStateChangeEvent { public final BlockPos blockPos; public final BlockState newState; public BlockStateChangeEvent(BlockPos p,BlockState s){blockPos=p;newState=s;} }
