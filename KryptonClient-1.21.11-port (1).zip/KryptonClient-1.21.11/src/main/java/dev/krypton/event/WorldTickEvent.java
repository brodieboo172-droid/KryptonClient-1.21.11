package dev.krypton.event; public final class WorldTickEvent {}
