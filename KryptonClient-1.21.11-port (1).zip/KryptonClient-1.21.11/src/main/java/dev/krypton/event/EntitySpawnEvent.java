package dev.krypton.event;
import net.minecraft.entity.EntityType;
public final class EntitySpawnEvent { public final Packet packet; private boolean cancelled; public EntitySpawnEvent(EntityType<?> t){packet=new Packet(t);} public void cancel(){cancelled=true;} public boolean isCancelled(){return cancelled;} public static final class Packet { private final EntityType<?> type; public Packet(EntityType<?> t){type=t;} public EntityType<?> getEntityType(){return type;} } }
