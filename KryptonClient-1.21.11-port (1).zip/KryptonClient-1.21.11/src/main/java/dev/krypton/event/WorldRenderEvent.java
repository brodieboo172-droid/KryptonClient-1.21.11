package dev.krypton.event;
import dev.krypton.gui.render.ShapeMode; import dev.krypton.util.ColorValue; import net.minecraft.client.MinecraftClient; import net.minecraft.client.render.*; import net.minecraft.util.math.Box; import net.minecraft.util.math.Vec3d;
public final class WorldRenderEvent {
 public final Renderer renderer; public WorldRenderEvent(WorldRenderContext context){renderer=new Renderer(context);}
 public static final class Renderer {
  private final WorldRenderContext ctx;
  Renderer(WorldRenderContext c){ctx=c;}
  public void vqo(double x1,double y1,double z1,double x2,double y2,double z2,ColorValue side,ColorValue line,ShapeMode mode,int ignored){
   Vec3d cam=MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos(); Box b=new Box(x1-cam.x,y1-cam.y,z1-cam.z,x2-cam.x,y2-cam.y,z2-cam.z);
   VertexConsumer vc=ctx.consumers().getBuffer(RenderLayer.getLines()); WorldRenderer.drawBox(ctx.matrices(),vc,b,line.r/255f,line.g/255f,line.b/255f,line.a/255f);
  }
  public void fzs(double x1,double y1,double z1,double x2,double y2,double z2,ColorValue a,ColorValue b){aen(x1,y1,z1,x2,y2,z2,a);}
  public void aen(double x1,double y1,double z1,double x2,double y2,double z2,ColorValue c){
   Vec3d cam=MinecraftClient.getInstance().gameRenderer.getCamera().getCameraPos();
   VertexConsumer vc=ctx.consumers().getBuffer(RenderLayer.getLines());
   vc.vertex(ctx.matrices().peek(),(float)(x1-cam.x),(float)(y1-cam.y),(float)(z1-cam.z)).color(c.r,c.g,c.b,c.a).normal(ctx.matrices().peek(),0,1,0);
   vc.vertex(ctx.matrices().peek(),(float)(x2-cam.x),(float)(y2-cam.y),(float)(z2-cam.z)).color(c.r,c.g,c.b,c.a).normal(ctx.matrices().peek(),0,1,0);
  }
 }
}
