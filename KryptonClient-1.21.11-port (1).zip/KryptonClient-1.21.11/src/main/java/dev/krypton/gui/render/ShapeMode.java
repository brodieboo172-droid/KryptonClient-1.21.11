package dev.krypton.gui.render;
public enum ShapeMode { OUTLINE, SIDES, BOTH }
