package dev.krypton.module.KrModules;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.krypton.event.Subscribe;
import dev.krypton.event.WorldTickEvent;
import dev.krypton.h;
import dev.krypton.integration.discord.DiscordEmbed;
import dev.krypton.integration.discord.DiscordWebhook;
import dev.krypton.module.Category;
import dev.krypton.module.Module;
import dev.krypton.setting.BooleanSetting;
import dev.krypton.setting.EnchantmentOption;
import dev.krypton.setting.EnchantmentSetting;
import dev.krypton.setting.ItemSetting;
import dev.krypton.setting.ModeSetting;
import dev.krypton.setting.NumberSetting;
import dev.krypton.setting.Setting;
import dev.krypton.setting.StringSetting;
import dev.krypton.util.ColorValue;
import dev.krypton.util.MathUtil;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

public class AuctionSniper extends Module {

   public ItemSetting snipingItem;
   public EnchantmentSetting enchantments;
   public EnchantmentSetting blacklistEnchantments;
   public StringSetting price;
   public BooleanSetting quickBuy;
   public ModeSetting mode;
   public StringSetting apiKey;
   public NumberSetting refreshDelay;
   public NumberSetting buyDelay;
   public NumberSetting apiRefreshRate;
   public BooleanSetting showApiNotifications;
   public BooleanSetting autoResell;
   public StringSetting resellPrice;
   public StringSetting webhook;

   public HttpClient httpClient;
   public Gson gson;
   public Map<String, Double> thresholdMap;
   public int delayTicks;
   public boolean readyToBuy;
   public long lastApiQueryTime;
   public boolean apiQuerying;
   public boolean targetFoundInApi;
   public boolean waitingForResell;
   public boolean autoReselling;
   public boolean awaitingConfirm;
   public int retryTimer;
   public int currentAuctionStep;
   public String sellerName;
   public boolean pendingWebhookSend;
   public Item snipedItem;
   public double snipedPrice;
   public String snipedSeller;
   public int resellTimeout;
   public Map<String, Integer> inventorySnapshot;

   public AuctionSniper() {
      super("Auction Sniper", "Snipes items on auction house for cheap", -1, Category.DONUT);

      this.snipingItem = new ItemSetting("Sniping Item", Items.AIR);
      this.enchantments = new EnchantmentSetting("Enchantments");
      this.blacklistEnchantments = (new EnchantmentSetting("Blacklist")).setDescription("Enchantments ModeSetting avoid (e.g. curses)");
      this.price = new StringSetting("Price", "1k");
      this.quickBuy = (new BooleanSetting("Quick Buy", false)).setDescription("Requires Donut+ rank but recommend not to use HIGH RISK");
      this.mode = (new ModeSetting("Mode", AuctionMode.MANUAL, AuctionMode.class)).setDescription("Manual is faster but api doesnt require auction gui opened all the time");
      this.apiKey = (new StringSetting("Api Key", "")).setDescription("You can get it by typing /api in chat").doNotSave();
      this.refreshDelay = new NumberSetting("Refresh Delay", 0.0, 100.0, 2.0, 1.0);
      this.buyDelay = new NumberSetting("Buy Delay", 0.0, 100.0, 2.0, 1.0);
      this.apiRefreshRate = (new NumberSetting("API Refresh Rate", 10.0, 5000.0, 250.0, 10.0)).setDescription("How often to query the API (in milliseconds)");
      this.showApiNotifications = (new BooleanSetting("Show API Notifications", true)).setDescription("Show chat notifications for API actions");
      this.autoResell = new BooleanSetting("Auto Resell", false);
      this.resellPrice = new StringSetting("Resell Price", "1k");
      this.webhook = (new StringSetting("Webhook", "")).setDescription("Discord webhook to notify when an item is sniped").doNotSave();

      this.thresholdMap = new HashMap<>();
      this.lastApiQueryTime = 0L;
      this.apiQuerying = false;
      this.targetFoundInApi = false;
      this.waitingForResell = false;
      this.autoReselling = false;
      this.awaitingConfirm = false;
      this.retryTimer = 0;
      this.currentAuctionStep = -1;
      this.sellerName = "";
      this.pendingWebhookSend = false;
      this.snipedItem = Items.AIR;
      this.snipedPrice = -1.0;
      this.snipedSeller = "";
      this.resellTimeout = 0;
      this.inventorySnapshot = Collections.emptyMap();

      this.httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).build();
      this.gson = new Gson();

      this.apiKey.visibleWhen(this::isApiMode);
      this.apiRefreshRate.visibleWhen(this::isApiMode);
      this.showApiNotifications.visibleWhen(this::isApiMode);
      this.refreshDelay.visibleWhen(this::isManualMode);
      this.resellPrice.visibleWhen(this.autoResell::getValue);

      this.addSettings(new Setting[]{
              this.snipingItem, this.enchantments, this.blacklistEnchantments, this.price,
              this.quickBuy, this.mode, this.apiKey, this.refreshDelay, this.buyDelay,
              this.apiRefreshRate, this.showApiNotifications, this.autoResell, this.resellPrice, this.webhook
      });
   }

   public static double parsePrice(String text) {
      return MathUtil.parseAbbreviatedNumber(text);
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.resetState();
   }

   @Override
   public void onDisable() {
      super.onDisable();
      this.resetState();
   }

   @Subscribe
   public void onTick(WorldTickEvent event) {
      if (this.mc.player == null) return;

      if (this.delayTicks > 0) {
         this.delayTicks--;
         return;
      }

      if (this.mode.is(AuctionMode.API)) {
         this.handleApiTick();
         return;
      }

      if (this.mode.is(AuctionMode.MANUAL)) {
         ScreenHandler currentHandler = this.mc.player.currentScreenHandler;

         if (this.pendingWebhookSend) {
            if (this.resellTimeout-- <= 0) {
               this.pendingWebhookSend = false;
               this.inventorySnapshot = Collections.emptyMap();
            } else if (this.hasInventoryChanged(this.snipedItem)) {
               ItemStack snipedStack = this.findItemStackInInventory(this.snipedItem);
               if (snipedStack == null) {
                  snipedStack = new ItemStack(this.snipedItem);
               }
               this.sendDiscordWebhook(snipedStack, this.snipedPrice, this.snipedSeller);
               this.pendingWebhookSend = false;
               this.inventorySnapshot = Collections.emptyMap();
            }
         }

         if (this.autoResell.getValue() && this.waitingForResell) {
            if (!this.mc.player.getInventory().getStack(0).isOf(Items.AIR)) {
               double targetPrice = parsePrice(this.resellPrice.getValue()) * this.mc.player.getInventory().getStack(0).getCount();
               this.mc.getNetworkHandler().sendChatCommand("ah sell " + targetPrice);
               this.delayTicks = 20;
               this.waitingForResell = false;
               return;
            }
         }

         if (this.autoReselling) {
            if (this.mc.player.getInventory().getStack(0).isOf(Items.AIR)) {
               this.autoReselling = false;
               this.awaitingConfirm = false;
               this.delayTicks = 40;
               return;
            }
            if (this.mc.player.getInventory().getSelectedSlot() != 0) {
               h.vtj(0);
            }
            return;
         }

         if (this.awaitingConfirm) {
            this.delayTicks = 1200;
            this.awaitingConfirm = false;
            return;
         }

         if (currentHandler instanceof GenericContainerScreenHandler containerHandler) {
            if (containerHandler.getRows() == 6) {
               this.handleAuctionGui(containerHandler);
            } else if (containerHandler.getRows() == 3) {
               this.handleConfirmationGui(containerHandler);
            }
         } else {
            Item searchItem = this.snipingItem.getValue();
            String itemName = (new ItemStack(searchItem)).getName().getString();
            StringBuilder enchantQuery = new StringBuilder();

            for (EnchantmentOption option : this.enchantments.getValues()) {
               enchantQuery.append(option.getSearchText()).append(" ");
            }

            ClientPlayNetworkHandler networkHandler = this.mc.getNetworkHandler();
            if (networkHandler != null) {
               networkHandler.sendChatCommand("ah " + itemName + " " + enchantQuery.toString().trim());
            }
            this.delayTicks = 20;
         }
      }
   }

   public void handleApiTick() {
      if (this.targetFoundInApi) {
         ScreenHandler currentHandler = this.mc.player.currentScreenHandler;
         if (currentHandler instanceof GenericContainerScreenHandler containerHandler) {
            this.currentAuctionStep = -1;
            if (containerHandler.getRows() == 6) {
               this.handleAuctionGui(containerHandler);
               return;
            }
            if (containerHandler.getRows() == 3) {
               this.handleConfirmationGui(containerHandler);
               return;
            }
         }
         if (this.currentAuctionStep == -1) {
            this.mc.getNetworkHandler().sendChatCommand("ah " + this.sellerName);
            this.currentAuctionStep = 0;
            return;
         }
         if (this.currentAuctionStep <= 40) {
            this.currentAuctionStep++;
            return;
         }
         this.targetFoundInApi = false;
         this.sellerName = "";
         return;
      }

      if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler && this.mc.currentScreen.getTitle().getString().contains("Page")) {
         this.mc.player.closeHandledScreen();
         this.delayTicks = 20;
         return;
      }

      if (this.apiQuerying) {
         return;
      }

      long currentTime = System.currentTimeMillis();
      if (currentTime - this.lastApiQueryTime <= (long) this.apiRefreshRate.getInt()) return;
      this.lastApiQueryTime = currentTime;

      if (this.apiKey.getValue().isEmpty()) {
         if (this.showApiNotifications.getValue()) {
            this.mc.player.sendMessage(Text.of("§cAPI key is not set. Set it using /api in-game."), false);
         }
         return;
      }

      this.apiQuerying = true;
      this.fetchAuctionDataAsync().thenAccept(this::processApiAuctions);
   }

   public CompletableFuture<List<JsonObject>> fetchAuctionDataAsync() {
      return CompletableFuture.supplyAsync(this::queryAuctionApi);
   }

   public void processApiAuctions(List<JsonObject> auctions) {
      for (JsonObject auction : auctions) {
         try {
            String itemId = auction.getAsJsonObject("item").get("id").getAsString();
            if (itemId.toLowerCase().contains("shulker_box")) {
               continue;
            }

            long auctionPrice = auction.get("price").getAsLong();
            String seller = auction.getAsJsonObject("seller").get("name").getAsString();

            for (Entry<String, Double> entry : this.thresholdMap.entrySet()) {
               String targetKey = entry.getKey();
               double maxAllowedPrice = entry.getValue();

               if (itemId.contains(targetKey) && auctionPrice <= maxAllowedPrice) {
                  if (this.showApiNotifications.getValue() && this.mc.player != null) {
                     this.mc.player.sendMessage(
                             Text.of("§aFound " + itemId + " for " + this.formatPrice(auctionPrice) + " §r(threshold: " + this.formatPrice(maxAllowedPrice) + ") §afrom seller: " + seller),
                             false
                     );
                  }
                  this.targetFoundInApi = true;
                  this.sellerName = seller;
                  return;
               }
            }
         } catch (Exception e) {
            if (this.showApiNotifications.getValue() && this.mc.player != null) {
               this.mc.player.sendMessage(Text.of("§cError processing auction: " + e.getMessage()), false);
            }
            break;
         }
      }
   }

   public void handleAuctionGui(GenericContainerScreenHandler containerHandler) {
      ItemStack sortSlot = containerHandler.getSlot(47).getStack();
      if (sortSlot.isOf(Items.AIR)) {
         this.delayTicks = 2;
      } else {
         for (Text tooltipLine : sortSlot.getTooltip(TooltipContext.DEFAULT, this.mc.player, TooltipType.BASIC)) {
            String text = tooltipLine.toString();
            if (text.contains("Recently Listed") && (tooltipLine.getStyle().toString().contains("white") || text.contains("white"))) {
               this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, 47, 1, SlotActionType.QUICK_MOVE, this.mc.player);
               this.delayTicks = 5;
               return;
            }
         }

         for (int slot = 0; slot < 44; slot++) {
            ItemStack itemStack = containerHandler.getSlot(slot).getStack();
            if (!this.isShulkerBox(itemStack) && itemStack.isOf(this.snipingItem.getValue()) && this.matchesCriteria(itemStack)) {
               if (this.readyToBuy) {
                  this.mc.interactionManager.clickSlot(
                          this.mc.player.currentScreenHandler.syncId,
                          slot,
                          1,
                          this.quickBuy.getValue() ? SlotActionType.QUICK_MOVE : SlotActionType.PICKUP,
                          this.mc.player
                  );
                  this.waitingForResell = true;
                  this.retryTimer = 60;
                  this.readyToBuy = false;
                  if (this.quickBuy.getValue()) {
                     List<Text> tooltip = itemStack.getTooltip(TooltipContext.DEFAULT, this.mc.player, TooltipType.BASIC);
                     double itemPrice = this.extractPriceFromTooltip(tooltip);
                     this.prepareWebhookNotification(itemStack.getItem(), itemPrice, "");
                  }
                  return;
               } else {
                  this.readyToBuy = true;
                  this.delayTicks = this.buyDelay.getInt();
                  return;
               }
            }
         }

         if (this.targetFoundInApi) {
            this.targetFoundInApi = false;
            this.sellerName = "";
            this.mc.player.closeHandledScreen();
            return;
         }

         this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, 49, 1, SlotActionType.QUICK_MOVE, this.mc.player);
         this.delayTicks = this.refreshDelay.getInt();
      }
   }

   public void handleConfirmationGui(GenericContainerScreenHandler containerHandler) {
      ItemStack confirmItem = containerHandler.getSlot(13).getStack();
      if (this.isShulkerBox(confirmItem)) {
         if (this.targetFoundInApi) {
            this.targetFoundInApi = false;
            this.sellerName = "";
         }
         this.mc.player.closeHandledScreen();
         this.delayTicks = 10;
         return;
      }

      if (this.matchesCriteria(confirmItem)) {
         this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, 15, 1, SlotActionType.QUICK_MOVE, (PlayerEntity) this.mc.player);
         this.delayTicks = 20;
         List<Text> tooltip = confirmItem.getTooltip(Item.TooltipContext.DEFAULT, (PlayerEntity) this.mc.player, TooltipType.BASIC);
         double priceVal = this.extractPriceFromTooltip(tooltip);
         this.prepareWebhookNotification(confirmItem.getItem(), priceVal, "");
      }

      if (this.targetFoundInApi) {
         this.targetFoundInApi = false;
         this.sellerName = "";
      }
   }

   public double extractPriceFromTooltip(List<Text> tooltip) {
      if (tooltip != null && !tooltip.isEmpty()) {
         for (Text line : tooltip) {
            String text = line.getString();
            if (text.matches("(?i).*price\\s*:\\s*\\$?.*")) {
               String cleanText = text.replaceAll("[,$]", "");
               Pattern pattern = Pattern.compile("([\\d]+(?:\\.[\\d]+)?)\\s*([KMBT])?", Pattern.CASE_INSENSITIVE);
               Matcher matcher = pattern.matcher(cleanText);
               if (matcher.find()) {
                  String numberPart = matcher.group(1);
                  String unitPart = matcher.group(2) != null ? matcher.group(2).toUpperCase() : "";
                  return parsePrice(numberPart + unitPart);
               }
            }
         }
      }
      return -1.0;
   }

   public boolean matchesCriteria(ItemStack itemStack) {
      for (EnchantmentOption option : this.enchantments.getValues()) {
         if (!option.matches(itemStack)) return false;
      }

      for (EnchantmentOption option : this.blacklistEnchantments.getValues()) {
         if (option.matches(itemStack)) return false;
      }

      List<Text> tooltips = itemStack.getTooltip(Item.TooltipContext.DEFAULT, (PlayerEntity) this.mc.player, TooltipType.BASIC);
      double singleItemPrice = this.extractPriceFromTooltip(tooltips) / (double) itemStack.getCount();
      double maxPrice = parsePrice(this.price.getValue());

      if (maxPrice == -1.0) {
         if (this.mc.player != null) {
            this.mc.player.sendMessage(Text.of("Invalid Price"), true);
         }
         this.setEnabled(false);
         return false;
      }

      if (singleItemPrice != -1.0) {
         return singleItemPrice <= maxPrice;
      }

      if (this.mc.player != null) {
         this.mc.player.sendMessage(Text.of("Invalid Auction Item Price"), true);
      }
      this.setEnabled(false);
      return false;
   }

   public String formatPrice(double priceVal) {
      if (priceVal >= 1.0E9) return String.format("%.2fB", priceVal / 1.0E9);
      if (priceVal >= 1000000.0) return String.format("%.2fM", priceVal / 1000000.0);
      if (priceVal >= 1000.0) return String.format("%.2fK", priceVal / 1000.0);
      return String.format("%.2f", priceVal);
   }

   public void prepareWebhookNotification(Item item, double priceVal, String seller) {
      String webhookUrl = this.webhook.getValue();
      if (webhookUrl == null || webhookUrl.isEmpty()) return;

      this.snipedItem = item != null ? item : Items.AIR;
      this.snipedPrice = priceVal;
      this.snipedSeller = seller != null ? seller : "";
      this.inventorySnapshot = this.takeInventorySnapshot();
      this.resellTimeout = 80;
      this.pendingWebhookSend = true;
   }

   public Map<String, Integer> takeInventorySnapshot() {
      Map<String, Integer> snapshot = new HashMap<>();
      if (this.mc.player == null) return snapshot;

      for (int slot = 0; slot < this.mc.player.getInventory().size(); slot++) {
         ItemStack stack = this.mc.player.getInventory().getStack(slot);
         if (stack != null && !stack.isOf(Items.AIR)) {
            String key = stack.getItem().toString();
            snapshot.put(key, snapshot.getOrDefault(key, 0) + stack.getCount());
         }
      }
      return snapshot;
   }

   public boolean hasInventoryChanged(Item item) {
      if (this.mc.player == null || item == null || item == Items.AIR) return false;
      Map<String, Integer> currentInventory = this.takeInventorySnapshot();
      String itemKey = item.toString();
      int previousCount = this.inventorySnapshot.getOrDefault(itemKey, 0);
      int currentCount = currentInventory.getOrDefault(itemKey, 0);
      return currentCount > previousCount;
   }

   public ItemStack findItemStackInInventory(Item item) {
      if (this.mc.player == null || item == null) return null;
      for (int slot = 0; slot < this.mc.player.getInventory().size(); slot++) {
         ItemStack stack = this.mc.player.getInventory().getStack(slot);
         if (stack != null && stack.getItem() == item && !stack.isOf(Items.AIR)) {
            return stack;
         }
      }
      return null;
   }

   public void sendDiscordWebhook(ItemStack itemStack, double priceVal, String seller) {
      String webhookUrl = this.webhook.getValue();
      if (webhookUrl == null || webhookUrl.isEmpty()) return;

      DiscordWebhook client = new DiscordWebhook(webhookUrl);
      client.setUsername("Auction Sniper");

      DiscordEmbed embed = new DiscordEmbed();
      embed.setTitle("Item Sniped");
      embed.setThumbnail("https://images-ext-1.discordapp.net/external/fPjc06PStppRMPyq0YJZFo5iuxSl5YrEVYkmxjQAKfg/%3Fsize%3D1024/https/cdn.discordapp.com/icons/1352381453572505672/25f01bf00ce185091e3c179852296c67.png?format=webp&quality=lossless&width=80&height=80");
      embed.setColor(ColorValue.YELLOW);
      embed.setFooter("https://discord.gg/kryptonclient", "https://cdn.discordapp.com/icons/1352381453572505672/25f01bf00ce185091e3c179852296c67.png?size=1024");

      String itemName = itemStack == null ? this.snipedItem.toString() : itemStack.getName().getString();
      int count = itemStack != null ? itemStack.getCount() : 1;
      String countSuffix = count > 1 ? " x" + count : "";

      embed.addField("Item:", itemName + countSuffix, true);
      embed.addField("Price:", priceVal > 0.0 ? this.formatPrice(priceVal) : "Unknown", true);
      if (seller != null && !seller.isEmpty()) {
         embed.addField("Seller:", seller, true);
      }

      client.addEmbed(embed);
      CompletableFuture.runAsync(() -> {
         try {
            client.execute();
         } catch (IOException ignored) {}
      });
   }

   public void resetState() {
      this.delayTicks = 0;
      this.readyToBuy = false;
      this.lastApiQueryTime = 0L;
      this.thresholdMap.clear();
      this.apiQuerying = false;
      this.targetFoundInApi = false;
      this.waitingForResell = false;
      this.awaitingConfirm = false;
      this.autoReselling = false;
      this.retryTimer = 0;
      this.currentAuctionStep = -1;
      this.sellerName = "";
      this.pendingWebhookSend = false;
      this.inventorySnapshot = Collections.emptyMap();
   }

   public boolean isShulkerBox(ItemStack itemStack) {
      if (itemStack == null || itemStack.isEmpty()) return false;
      return itemStack.getItem().toString().toLowerCase().contains("shulker_box");
   }

   public List<JsonObject> queryAuctionApi() {
      try {
         String endpoint = "https://api.donutsmp.net/v1/auction/list/1";
         HttpRequest request = HttpRequest.newBuilder()
                 .uri(URI.create(endpoint))
                 .header("Authorization", "Bearer " + this.apiKey.getValue())
                 .header("Content-Type", "application/json")
                 .POST(HttpRequest.BodyPublishers.ofString("{\"sort\": \"recently_listed\"}"))
                 .build();

         HttpResponse<String> response = this.httpClient.send(request, HttpResponse.BodyHandlers.ofString());
         if (response.statusCode() != 200) {
            if (this.showApiNotifications.getValue() && this.mc.player != null) {
               this.mc.player.sendMessage(Text.literal("§cAPI Error: " + response.statusCode()), false);
            }
            this.apiQuerying = false;
            return new ArrayList<>();
         }

         JsonArray results = this.gson.fromJson(response.body(), JsonObject.class).getAsJsonArray("result");
         List<JsonObject> auctions = new ArrayList<>();
         for (JsonElement element : results) {
            auctions.add(element.getAsJsonObject());
         }
         this.apiQuerying = false;
         return auctions;
      } catch (Throwable error) {
         this.apiQuerying = false;
         if (this.showApiNotifications.getValue() && this.mc.player != null) {
            this.mc.player.sendMessage(Text.literal("§cAPI Error: " + error.getMessage()), false);
         }
         return Collections.emptyList();
      }
   }

   public Boolean isManualMode() {
      return this.mode.is(AuctionMode.MANUAL);
   }

   public Boolean isApiMode() {
      return this.mode.is(AuctionMode.API);
   }
}