package dev.krypton.module.KrModules;

import dev.krypton.event.ChunkDataEvent;
import dev.krypton.event.GameJoinEvent;
import dev.krypton.event.Subscribe;
import dev.krypton.event.WorldRenderEvent;
import dev.krypton.gui.render.ShapeMode;
import dev.krypton.gw;
import dev.krypton.module.Category;
import dev.krypton.module.Module;
import dev.krypton.notification.Notifications;
import dev.krypton.rq;
import dev.krypton.setting.Setting;
import dev.krypton.setting.StringSetting;
import dev.krypton.util.ColorValue;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.random.RandomSplitter;
import net.minecraft.util.math.random.Xoroshiro128PlusPlusRandom;
import net.minecraft.world.chunk.WorldChunk;

public class SeedChunkFinder extends Module {

   public StringSetting seedSetting = new StringSetting("Server Seed", "");
   public double[] thresholds = new double[]{1.0, 0.875, 0.75, 0.625, 0.5, 0.375, 0.25, 0.125};
   public RandomSplitter randomSplitter;
   public ExecutorService executor;
   public Set<ChunkPos> suspiciousChunks = new HashSet<>();

   public SeedChunkFinder() {
      super("Seed Chunk Finder", "Finds suspicious chunks using configurable server seed", -1, Category.BASE_FINDING);
      this.addSettings(new Setting[]{this.seedSetting});
   }

   @Override
   public void onEnable() {
      long seed;
      try {
         seed = Long.parseLong(this.seedSetting.getValue());
      } catch (NumberFormatException e) {
         this.setEnabled(false);
         return;
      }

      this.executor = Executors.newSingleThreadExecutor();
      this.randomSplitter = (new Xoroshiro128PlusPlusRandom(seed)).nextSplitter().split("minecraft:deepslate").nextSplitter();
      this.suspiciousChunks = new HashSet<>();

      if (this.lr.player != null && this.lr.world != null) {
         this.scanLoadedChunks();
      }

      super.onEnable();
   }

   @Override
   public void onDisable() {
      if (this.executor != null && !this.executor.isShutdown()) {
         this.executor.shutdownNow();
      }
      super.onDisable();
   }

   @Subscribe
   public void onGameJoin(GameJoinEvent event) {
      this.suspiciousChunks.clear();
   }

   @Subscribe
   public void onChunkData(ChunkDataEvent event) {
      if (this.lr.world != null) {
         WorldChunk chunk = this.lr.world.getChunk(event.packet.getChunkX(), event.packet.getChunkZ());
         this.processChunkAsync(chunk);
      }
   }

   @Subscribe
   public void onRender(WorldRenderEvent event) {
      var iterator = this.suspiciousChunks.iterator();
      while (iterator.hasNext()) {
         ChunkPos chunkPos = iterator.next();
         if (!this.lr.world.isChunkLoaded(chunkPos.x, chunkPos.z)) {
            iterator.remove();
         } else {
            double startX = chunkPos.getStartX();
            double startZ = chunkPos.getStartZ();
            double endX = startX + 16.0;
            double endZ = startZ + 16.0;
            ColorValue color = new ColorValue(0, 255, 0, 100);
            event.renderer.vqo(startX, 63.0, startZ, endX, 63.1F, endZ, color, color, ShapeMode.OUTLINE, 0);
         }
      }
   }

   public void scanLoadedChunks() {
      for (Object obj : rq.zo()) {
         WorldChunk chunk = (WorldChunk) obj;
         this.processChunkAsync(chunk);
      }
   }

   public void processChunkAsync(WorldChunk chunk) {
      if (this.executor != null && !this.executor.isShutdown()) {
         this.executor.submit(() -> this.analyzeChunk(chunk));
      }
   }

   public boolean isGenerationStateValid(int x, int y, int z) {
      if (y >= 8) return false;
      if (y <= 0) return true;
      
      double threshold = this.thresholds[y];
      return (double) this.randomSplitter.split(x, y, z).nextFloat() < threshold;
   }

   public void analyzeChunk(WorldChunk chunk) {
      ChunkPos chunkPos = chunk.getPos();
      int startX = chunkPos.getStartX();
      int startZ = chunkPos.getStartZ();
      gw blockProvider = new gw();

      for (int x = startX; x < startX + 16; x++) {
         for (int z = startZ; z < startZ + 16; z++) {
            for (int y = 1; y < 7; y++) {
               Block block = blockProvider.uks(x, y, z).getBlock();
               if (!this.isGenerationStateValid(x, y, z) && block == Blocks.DEEPSLATE) {
                  if (this.suspiciousChunks.add(chunkPos)) {
                     Notifications.success("ChunkFinder", "X: " + startX + " Z: " + startZ);
                  }
               }
            }
         }
      }
   }
}