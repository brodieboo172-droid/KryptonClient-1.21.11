package dev.krypton.module.KrModules;

import dev.krypton.event.BlockStateChangeEvent;
import dev.krypton.event.ChunkDataEvent;
import dev.krypton.event.Subscribe;
import dev.krypton.event.WorldRenderEvent;
import dev.krypton.gpz;
import dev.krypton.gui.render.ShapeMode;
import dev.krypton.module.Category;
import dev.krypton.module.Module;
import dev.krypton.rq;
import dev.krypton.setting.BooleanSetting;
import dev.krypton.setting.NumberSetting;
import dev.krypton.setting.Setting;
import dev.krypton.util.ColorValue;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.KelpBlock;
import net.minecraft.block.TwistingVinesBlock;
import net.minecraft.block.TwistingVinesPlantBlock;
import net.minecraft.block.VineBlock;
import net.minecraft.block.WeepingVinesBlock;
import net.minecraft.block.WeepingVinesPlantBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.PillagerEntity;
import net.minecraft.entity.mob.ZombieVillagerEntity;
import net.minecraft.entity.passive.LlamaEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public class SuspiciousESP extends Module {

   public static int maxDistance = 10;
   public BooleanSetting wanderingTraders = new BooleanSetting("Wandering Traders", true);
   public BooleanSetting villagers = new BooleanSetting("Villagers", true);
   public BooleanSetting llamas = new BooleanSetting("Llamas", true);
   public BooleanSetting pillagers = new BooleanSetting("Pillagers", true);
   public BooleanSetting deepslate = new BooleanSetting("Deepslate", true);
   public BooleanSetting rotatedDeepslate = new BooleanSetting("Rotated Deepslate", true);
   public BooleanSetting vines = new BooleanSetting("Vines", true);
   public BooleanSetting kelp = new BooleanSetting("Kelp", true);
   public BooleanSetting amethyst = new BooleanSetting("Amethyst Clusters", true);
   public NumberSetting alpha = new NumberSetting("Alpha", 1.0, 255.0, 100.0, 1.0);
   public BooleanSetting tracers = new BooleanSetting("Tracers", false);
   public NumberSetting deepslateMinY = new NumberSetting("Deepslate Min Y", -64.0, 128.0, 16.0, 1.0);
   public NumberSetting deepslateMaxY = new NumberSetting("Deepslate Max Y", -64.0, 320.0, 128.0, 1.0);

   public Map<BlockPos, SuspiciousBlockType> blockMap = new ConcurrentHashMap<>();
   public Set<ChunkPos> kelpChunks = ConcurrentHashMap.newKeySet();
   public Set<Integer> entityIds = ConcurrentHashMap.newKeySet();
   public ExecutorService executor = Executors.newFixedThreadPool(2);

   public SuspiciousESP() {
      super("Suspicious ESP", "Detects suspicious entities and blocks", -1, Category.BASE_FINDING);
      this.deepslateMinY.visibleWhen(this::isDeepslateFilterActive);
      this.deepslateMaxY.visibleWhen(this::isDeepslateFilterActive);
      this.addSettings(new Setting[]{
         this.wanderingTraders, this.villagers, this.llamas, this.pillagers, 
         this.deepslate, this.rotatedDeepslate, this.vines, this.kelp, 
         this.amethyst, this.alpha, this.tracers, this.deepslateMinY, this.deepslateMaxY
      });
   }

   @Override
   public void onEnable() {
      if (this.lr.player == null || this.lr.world == null) return;

      this.blockMap.clear();
      this.kelpChunks.clear();
      this.entityIds.clear();

      for (Object obj : rq.zo()) {
         WorldChunk chunk = (WorldChunk) obj;
         this.executor.submit(() -> this.scanChunk(chunk));
      }

      super.onEnable();
   }

   @Override
   public void onDisable() {
      this.blockMap.clear();
      this.kelpChunks.clear();
      this.entityIds.clear();
      super.onDisable();
   }

   @Subscribe
   public void onChunkData(ChunkDataEvent event) {
      if (this.lr.world != null) {
         WorldChunk chunk = this.lr.world.getChunk(event.packet.getChunkX(), event.packet.getChunkZ());
         this.executor.submit(() -> this.scanChunk(chunk));
      }
   }

   @Subscribe
   public void onBlockStateChange(BlockStateChangeEvent event) {
      if (this.lr.world == null) return;

      BlockPos pos = event.blockPos.toImmutable();
      BlockState state = event.newState;
      Block block = state.getBlock();

      if (this.amethyst.getValue() && block == Blocks.AMETHYST_CLUSTER) {
         this.blockMap.put(pos, SuspiciousBlockType.AMETHYST);
         return;
      }
      if (this.deepslate.getValue() && block == Blocks.DEEPSLATE && pos.getY() >= this.deepslateMinY.getInt() && pos.getY() <= this.deepslateMaxY.getInt()) {
         this.blockMap.put(pos, SuspiciousBlockType.DEEPSLATE);
         return;
      }
      if (this.rotatedDeepslate.getValue() && this.isRotatedDeepslate(state, pos.getY())) {
         this.blockMap.put(pos, SuspiciousBlockType.PLANT);
         return;
      }
      if (this.vines.getValue() && this.isVine(block)) {
         this.blockMap.put(pos, SuspiciousBlockType.VINE);
         return;
      }

      this.blockMap.remove(pos);
   }

   @Subscribe
   public void onRender(WorldRenderEvent event) {
      this.renderBlocks(event);
      this.renderEntities(event);
   }

   public void scanChunk(WorldChunk chunk) {
      if (this.lr.world == null || chunk == null) return;

      ChunkSection[] sections = chunk.getSectionArray();
      int bottomY = chunk.getBottomSectionCoord();
      int startX = chunk.getPos().getStartX();
      int startZ = chunk.getPos().getStartZ();
      ChunkPos chunkPos = chunk.getPos();
      Map<BlockPos, SuspiciousBlockType> foundBlocks = new HashMap<>();
      int kelpCount = 0;

      for (int secIndex = 0; secIndex < sections.length; secIndex++) {
         ChunkSection section = sections[secIndex];
         if (section != null && !section.isEmpty()) {
            int sectionMinY = (bottomY + secIndex) << 4;

            for (int x = 0; x < 16; x++) {
               for (int y = 0; y < 16; y++) {
                  for (int z = 0; z < 16; z++) {
                     BlockState state = section.getBlockState(x, y, z);
                     Block block = state.getBlock();
                     BlockPos pos = new BlockPos(startX + x, sectionMinY + y, startZ + z);

                     if (this.amethyst.getValue() && block == Blocks.AMETHYST_CLUSTER) {
                        foundBlocks.put(pos, SuspiciousBlockType.AMETHYST);
                     }
                     if (this.vines.getValue() && this.isVine(block)) {
                        foundBlocks.put(pos, SuspiciousBlockType.VINE);
                     }
                     if (this.rotatedDeepslate.getValue() && this.isRotatedDeepslate(state, pos.getY())) {
                        foundBlocks.put(pos, SuspiciousBlockType.PLANT);
                     }
                     if (this.deepslate.getValue() && block == Blocks.DEEPSLATE) {
                        int posY = pos.getY();
                        if (posY >= this.deepslateMinY.getInt() && posY <= this.deepslateMaxY.getInt()) {
                           foundBlocks.put(pos, SuspiciousBlockType.DEEPSLATE);
                        }
                     }
                     if (this.kelp.getValue() && block instanceof KelpBlock && state.get(KelpBlock.AGE) == 25) {
                        kelpCount++;
                     }
                  }
               }
            }
         }
      }

      this.blockMap.entrySet().removeIf(entry -> entry.getKey().getX() >> 4 == chunkPos.x && entry.getKey().getZ() >> 4 == chunkPos.z && !foundBlocks.containsKey(entry.getKey()));
      this.blockMap.putAll(foundBlocks);

      if (this.kelp.getValue() && kelpCount >= 10) {
         this.kelpChunks.add(chunkPos);
      } else {
         this.kelpChunks.remove(chunkPos);
      }
   }

   public boolean isRotatedDeepslate(BlockState state, int y) {
      if (y < this.deepslateMinY.getInt() || y > this.deepslateMaxY.getInt()) return false;
      if (!state.contains(Properties.AXIS)) return false;
      if (state.get(Properties.AXIS) == Axis.Y) return false;

      Block block = state.getBlock();
      return block == Blocks.DEEPSLATE || block == Blocks.POLISHED_DEEPSLATE || block == Blocks.DEEPSLATE_BRICKS || block == Blocks.DEEPSLATE_TILES || block == Blocks.CHISELED_DEEPSLATE;
   }

   public boolean isVine(Block block) {
      return block instanceof VineBlock || block instanceof TwistingVinesBlock || block instanceof TwistingVinesPlantBlock || block instanceof WeepingVinesBlock || block instanceof WeepingVinesPlantBlock;
   }

   public ColorValue getBlockColor(SuspiciousBlockType type, int alphaVal) {
      return switch (type) {
         case DEEPSLATE -> new ColorValue(0, 200, 255, alphaVal);
         case PLANT -> new ColorValue(255, 0, 255, alphaVal);
         case VINE -> new ColorValue(0, 255, 0, alphaVal);
         case AMETHYST -> new ColorValue(180, 0, 255, alphaVal);
      };
   }

   public ColorValue getEntityColor(SuspiciousEntityType type, int alphaVal) {
      return switch (type) {
         case WANDERING_TRADER, PILLAGER -> new ColorValue(255, 0, 0, alphaVal);
         case VILLAGER, ZOMBIE_VILLAGER -> new ColorValue(0, 255, 0, alphaVal);
         case LLAMA -> new ColorValue(255, 165, 0, alphaVal);
      };
   }

   public void renderBlocks(WorldRenderEvent event) {
      if (this.lr.world == null || this.lr.player == null) return;
      if (this.blockMap.isEmpty() && this.kelpChunks.isEmpty()) return;

      int playerChunkX = this.lr.player.getBlockX() >> 4;
      int playerChunkZ = this.lr.player.getBlockZ() >> 4;
      int viewDistance = this.lr.options.getClampedViewDistance();

      for (Entry<BlockPos, SuspiciousBlockType> entry : this.blockMap.entrySet()) {
         BlockPos pos = entry.getKey();
         int chunkX = pos.getX() >> 4;
         int chunkZ = pos.getZ() >> 4;

         if (Math.abs(chunkX - playerChunkX) <= viewDistance && Math.abs(chunkZ - playerChunkZ) <= viewDistance) {
            SuspiciousBlockType type = entry.getValue();
            ColorValue color = this.getBlockColor(type, this.alpha.getInt());
            event.renderer.vqo(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1.0F, pos.getY() + 1.0F, pos.getZ() + 1.0F, color, color, ShapeMode.OUTLINE, 0);

            if (this.tracers.getValue()) {
               event.renderer.fzs(
                  gpz.oeg.x, gpz.oeg.y, gpz.oeg.z,
                  (float) (pos.getX() + 0.5), (float) (pos.getY() + 0.5), (float) (pos.getZ() + 0.5),
                  this.getBlockColor(type, 255), this.getBlockColor(type, 255)
               );
            }
         }
      }

      if (this.kelp.getValue()) {
         ColorValue kelpColor = new ColorValue(0, 255, 255, this.alpha.getInt());
         for (ChunkPos pos : this.kelpChunks) {
            if (Math.abs(pos.x - playerChunkX) <= viewDistance && Math.abs(pos.z - playerChunkZ) <= viewDistance) {
               event.renderer.vqo(pos.getStartX(), 63.0, pos.getStartZ(), pos.getStartX() + 16, 63.0, pos.getStartZ() + 16, kelpColor, kelpColor, ShapeMode.OUTLINE, 0);
            }
         }
      }
   }

   public void renderEntities(WorldRenderEvent event) {
      if (this.lr.world == null || this.lr.player == null) return;

      this.entityIds.clear();

      for (Entity entity : this.lr.world.getEntities()) {
         SuspiciousEntityType type = null;

         if (this.wanderingTraders.getValue() && entity instanceof WanderingTraderEntity) {
            type = SuspiciousEntityType.WANDERING_TRADER;
         } else if (this.villagers.getValue() && entity instanceof VillagerEntity) {
            type = SuspiciousEntityType.VILLAGER;
         } else if (this.llamas.getValue() && entity instanceof LlamaEntity) {
            type = SuspiciousEntityType.LLAMA;
         } else if (this.villagers.getValue() && entity instanceof ZombieVillagerEntity) {
            type = SuspiciousEntityType.ZOMBIE_VILLAGER;
         } else if (this.pillagers.getValue() && entity instanceof PillagerEntity) {
            type = SuspiciousEntityType.PILLAGER;
         }

         if (type != null) {
            this.entityIds.add(entity.getId());
            Box box = entity.getBoundingBox();
            ColorValue color = this.getEntityColor(type, this.alpha.getInt());
            event.renderer.vqo(box.minX, box.minY, box.minZ, box.maxX, box.maxY, box.maxZ, color, color, ShapeMode.OUTLINE, 0);

            if (this.tracers.getValue()) {
               Vec3d pos = entity.getEntityPos().add(0.0, entity.getHeight() / 2.0F, 0.0);
               event.renderer.aen(gpz.oeg.x, gpz.oeg.y, gpz.oeg.z, pos.x, pos.y, pos.z, this.getEntityColor(type, 255));
            }
         }
      }
   }

   public Boolean isDeepslateFilterActive() {
      return this.deepslate.getValue() || this.rotatedDeepslate.getValue();
   }
}