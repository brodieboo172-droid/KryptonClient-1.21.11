package dev.krypton.module;
import dev.krypton.LocalRefs; import net.minecraft.client.MinecraftClient; import dev.krypton.setting.Setting;
public abstract class Module { protected final MinecraftClient mc=MinecraftClient.getInstance(); protected final LocalRefs lr=new LocalRefs(); private boolean enabled; public final String name,description; public final int key; public final Category category; protected Module(String n,String d,int k,Category c){name=n;description=d;key=k;category=c;lr.refresh();}
 public void addSettings(Setting[] s){} public boolean isEnabled(){return enabled;} public void setEnabled(boolean e){if(e==enabled)return;enabled=e;lr.refresh();if(e)onEnable();else onDisable();} public void toggle(){setEnabled(!enabled);} public void onEnable(){lr.refresh();} public void onDisable(){} public void refreshRefs(){lr.refresh();}
}
