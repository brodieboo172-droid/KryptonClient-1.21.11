package dev.krypton.module.KrModules;

public enum AutoSellMode {
   SELL,
   ORDER
}