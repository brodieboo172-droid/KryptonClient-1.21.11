package dev.krypton.module.KrModules;

import dev.krypton.event.Subscribe;
import dev.krypton.event.WorldTickEvent;
import dev.krypton.module.Category;
import dev.krypton.module.Module;
import dev.krypton.module.donut.AutoShopMode;
import dev.krypton.setting.ItemSetting;
import dev.krypton.setting.ModeSetting;
import dev.krypton.setting.NumberSetting;
import dev.krypton.setting.Setting;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AutoShop extends Module {
    public static Map<Item, int[]> itemSlots = new LinkedHashMap<>();
    public static List<Item> itemList = List.copyOf(itemSlots.keySet());

    public ItemSetting itemSetting;
    public ModeSetting modeSetting;
    public NumberSetting amountSetting;
    public NumberSetting delaySetting;
    public NumberSetting dropDelaySetting;

    private int tickDelay = 0;
    private int boughtStacks = 0;
    private boolean isDropping = false;
    private boolean isBuying = false;
    private boolean unusedFlag = false;
    private int syncId = -1;
    private int currentSyncId = -1;

    public AutoShop() {
        super("Auto Shop", "Automatically buys chosen item from /shop", -1, Category.DONUT);

        this.itemSetting = new ItemSetting("Item", Items.SHULKER_BOX, itemList);
        this.modeSetting = new ModeSetting("Mode", AutoShopMode.HXT, AutoShopMode.class);
        this.amountSetting = new NumberSetting("Amount", 1.0, 36.0, 36.0, 1.0)
                .setDescription("How many stacks of 64 to buy before clearing (e.g. 28 = 64x28)");
        this.delaySetting = new NumberSetting("Delay", 0.0, 20.0, 2.0, 1.0)
                .setDescription("Delay in ticks between actions");
        this.dropDelaySetting = new NumberSetting("Drop Delay", 0.0, 20.0, 1.0, 1.0)
                .setDescription("Delay in ticks between drops");

        this.dropDelaySetting.visibleWhen(this::isBTFMode);
        this.addSettings(new Setting[]{this.itemSetting, this.modeSetting, this.amountSetting, this.delaySetting, this.dropDelaySetting});
    }

    @Override
    public void onEnable() {
        super.onEnable();
        reset();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Subscribe
    public void onWorldTick(WorldTickEvent event) {
        if (this.mc.player == null) {
            return;
        }

        if (this.tickDelay > 0) {
            this.tickDelay--;
            return;
        }

        Item item = this.itemSetting.getValue();
        int[] slots = itemSlots.get(item);
        if (slots == null) {
            return;
        }

        boolean isMns = this.modeSetting.is(AutoShopMode.MNS);
        Object screenHandler = this.mc.player.currentScreenHandler;

        if (this.isDropping && isMns && screenHandler instanceof GenericContainerScreenHandler containerHandler) {
            int rows = containerHandler.getRows();
            if (rows == 3 && this.mc.currentScreen != null) {
                String title = this.mc.currentScreen.getTitle().getString();
                if (title.contains("Confirm") || title.contains("Delivery")) {
                    handleDeliveryScreen(containerHandler, item);
                    return;
                }
            } else if (rows == 6 || rows == 4) {
                handleDeliveryScreen(containerHandler, item);
                return;
            }
        }

        if (this.isDropping) {
            dropItems(item);
            return;
        }

        if (!(screenHandler instanceof GenericContainerScreenHandler genericContainerScreenHandler)) {
            this.isBuying = false;
            this.unusedFlag = false;
            this.syncId = -1;
            this.mc.getNetworkHandler().sendChatCommand("shop");
            this.tickDelay = 20;
            return;
        }

        if (genericContainerScreenHandler.getRows() != 3) {
            this.mc.player.closeHandledScreen();
            this.tickDelay = 10;
            return;
        }

        if (this.isBuying) {
            if (genericContainerScreenHandler.syncId == this.syncId) {
                this.tickDelay = 1;
                return;
            }

            if (!genericContainerScreenHandler.getSlot(slots[1]).getStack().isOf(item)) {
                this.mc.interactionManager.clickSlot(genericContainerScreenHandler.syncId, 17, 0, SlotActionType.PICKUP, this.mc.player);
                this.mc.interactionManager.clickSlot(genericContainerScreenHandler.syncId, 23, 0, SlotActionType.PICKUP, this.mc.player);
                this.boughtStacks++;
                this.tickDelay = this.delaySetting.getInt();

                if (this.boughtStacks >= this.amountSetting.getInt()) {
                    this.boughtStacks = 0;
                    this.isBuying = false;
                    this.isDropping = true;
                }
                return;
            }

            this.isBuying = false;
            this.unusedFlag = false;
            return;
        }

        if (genericContainerScreenHandler.getSlot(slots[1]).getStack().isOf(item)) {
            this.mc.interactionManager.clickSlot(genericContainerScreenHandler.syncId, slots[1], 0, SlotActionType.PICKUP, this.mc.player);
            this.isBuying = true;
            this.unusedFlag = false;
            this.syncId = genericContainerScreenHandler.syncId;
            this.tickDelay = this.delaySetting.getInt();
            return;
        }

        this.mc.interactionManager.clickSlot(genericContainerScreenHandler.syncId, slots[0], 0, SlotActionType.PICKUP, this.mc.player);
        this.tickDelay = this.delaySetting.getInt();
    }

    public void dropItems(Item item) {
        if (this.modeSetting.is(AutoShopMode.BTF)) {
            if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
                this.mc.player.closeHandledScreen();
                this.tickDelay = 3;
                return;
            }
        } else if (this.modeSetting.is(AutoShopMode.MNS)) {
            if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler) {
                this.mc.player.closeHandledScreen();
                this.tickDelay = 5;
                return;
            }

            if (this.mc.currentScreen == null) {
                ClientPlayerEntity player = this.mc.player;
                this.mc.setScreen(new InventoryScreen(player));
                this.tickDelay = 1;
                return;
            }
        } else {
            this.mc.getNetworkHandler().sendChatCommand("order " + item.getName().getString());
            this.tickDelay = 20;
            return;
        }

        int dropDelay = this.dropDelaySetting.getInt();
        for (int i = 0; i < 36; i++) {
            if (this.mc.player.getInventory().getStack(i).isOf(item)) {
                int slot = (i < 9) ? i + 36 : i;
                this.mc.interactionManager.clickSlot(0, slot, 1, SlotActionType.THROW, this.mc.player);
                if (dropDelay > 0) {
                    this.tickDelay = dropDelay;
                    return;
                }
            }
        }

        this.mc.setScreen(null);
        this.isDropping = false;
    }

    public void handleDeliveryScreen(GenericContainerScreenHandler screenHandler, Item item) {
        if (this.mc.currentScreen == null) {
            return;
        }

        int rows = screenHandler.getRows();
        if (rows == 6) {
            if (screenHandler.syncId == this.currentSyncId) {
                this.tickDelay = 2;
                return;
            }

            ItemStack slot47Stack = screenHandler.getSlot(47).getStack();
            if (slot47Stack.isOf(Items.AIR)) {
                this.currentSyncId = -1;
                this.mc.player.closeHandledScreen();
                this.tickDelay = 5;
                this.isDropping = false;
                return;
            }

            TooltipContext tooltipContext = TooltipContext.create(this.mc.world);
            Iterator<Text> tooltipIterator = slot47Stack.getTooltip(tooltipContext, this.mc.player, TooltipType.BASIC).iterator();

            while (tooltipIterator.hasNext()) {
                Text text = tooltipIterator.next();
                String textStr = text.toString();
                if (textStr.contains("Most Money Per Item") && (text.getStyle().toString().contains("white") || textStr.contains("white"))) {
                    for (int i = 0; i < 44; i++) {
                        if (screenHandler.getSlot(i).getStack().isOf(item)) {
                            this.mc.interactionManager.clickSlot(screenHandler.syncId, i, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                            this.currentSyncId = screenHandler.syncId;
                            this.tickDelay = 2;
                            return;
                        }
                    }
                    this.currentSyncId = -1;
                    this.mc.player.closeHandledScreen();
                    this.tickDelay = 10;
                    this.isDropping = false;
                    return;
                }
            }

            this.mc.interactionManager.clickSlot(screenHandler.syncId, 47, 1, SlotActionType.QUICK_MOVE, this.mc.player);
            this.currentSyncId = screenHandler.syncId;
            this.tickDelay = 2;
        } else if (rows == 4) {
            int startSlot = rows * 9;
            int endSlot = (rows + 4) * 9;

            for (int i = startSlot; i < endSlot; i++) {
                if (screenHandler.getSlot(i).getStack().isOf(item)) {
                    this.mc.interactionManager.clickSlot(screenHandler.syncId, i, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                    this.tickDelay = this.delaySetting.getInt();
                    return;
                }
            }
            this.mc.player.closeHandledScreen();
            this.tickDelay = 10;
        } else if (rows == 3) {
            this.mc.interactionManager.clickSlot(screenHandler.syncId, 15, 0, SlotActionType.PICKUP, this.mc.player);
            this.tickDelay = 10;
            this.isDropping = false;
            this.currentSyncId = -1;
        }
    }

    public void reset() {
        this.tickDelay = 0;
        this.boughtStacks = 0;
        this.isDropping = false;
        this.isBuying = false;
        this.unusedFlag = false;
        this.syncId = -1;
        this.currentSyncId = -1;
    }

    public boolean isBTFMode() {
        return this.modeSetting.is(AutoShopMode.BTF);
    }

    static {
        itemSlots.put(Items.ENDER_CHEST, new int[]{11, 9});
        itemSlots.put(Items.ENDER_PEARL, new int[]{11, 10});
        itemSlots.put(Items.END_STONE, new int[]{11, 11});
        itemSlots.put(Items.DRAGON_BREATH, new int[]{11, 12});
        itemSlots.put(Items.END_ROD, new int[]{11, 13});
        itemSlots.put(Items.CHORUS_FRUIT, new int[]{11, 14});
        itemSlots.put(Items.POPPED_CHORUS_FRUIT, new int[]{11, 15});
        itemSlots.put(Items.SHULKER_SHELL, new int[]{11, 16});
        itemSlots.put(Items.SHULKER_BOX, new int[]{11, 17});
        itemSlots.put(Items.BLAZE_ROD, new int[]{12, 9});
        itemSlots.put(Items.NETHER_WART, new int[]{12, 10});
        itemSlots.put(Items.GLOWSTONE_DUST, new int[]{12, 11});
        itemSlots.put(Items.MAGMA_CREAM, new int[]{12, 12});
        itemSlots.put(Items.GHAST_TEAR, new int[]{12, 13});
        itemSlots.put(Items.QUARTZ, new int[]{12, 14});
        itemSlots.put(Items.SOUL_SAND, new int[]{12, 15});
        itemSlots.put(Items.MAGMA_BLOCK, new int[]{12, 16});
        itemSlots.put(Items.CRYING_OBSIDIAN, new int[]{12, 17});
        itemSlots.put(Items.OBSIDIAN, new int[]{13, 9});
        itemSlots.put(Items.END_CRYSTAL, new int[]{13, 10});
        itemSlots.put(Items.RESPAWN_ANCHOR, new int[]{13, 11});
        itemSlots.put(Items.GLOWSTONE, new int[]{13, 12});
        itemSlots.put(Items.TOTEM_OF_UNDYING, new int[]{13, 13});
        itemSlots.put(Items.GOLDEN_APPLE, new int[]{13, 15});
        itemSlots.put(Items.EXPERIENCE_BOTTLE, new int[]{13, 16});
        itemSlots.put(Items.TIPPED_ARROW, new int[]{13, 17});
        itemSlots.put(Items.POTATO, new int[]{14, 9});
        itemSlots.put(Items.SWEET_BERRIES, new int[]{14, 10});
        itemSlots.put(Items.MELON_SLICE, new int[]{14, 11});
        itemSlots.put(Items.CARROT, new int[]{14, 12});
        itemSlots.put(Items.APPLE, new int[]{14, 13});
        itemSlots.put(Items.COOKED_CHICKEN, new int[]{14, 14});
        itemSlots.put(Items.COOKED_BEEF, new int[]{14, 15});
        itemSlots.put(Items.GOLDEN_CARROT, new int[]{14, 16});
        itemSlots.put(Items.ENCHANTED_GOLDEN_APPLE, new int[]{14, 17});
    }
}