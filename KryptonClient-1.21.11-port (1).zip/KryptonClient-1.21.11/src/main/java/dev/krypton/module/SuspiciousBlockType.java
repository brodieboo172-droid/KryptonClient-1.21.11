package dev.krypton.module.KrModules;

public enum SuspiciousBlockType {
   DEEPSLATE,
   PLANT,
   VINE,
   AMETHYST;
}