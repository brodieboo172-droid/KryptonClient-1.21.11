package dev.krypton.module.KrModules;

import dev.krypton.event.ChunkDataEvent;
import dev.krypton.event.GameJoinEvent;
import dev.krypton.event.Subscribe;
import dev.krypton.event.WorldRenderEvent;
import dev.krypton.gui.render.ShapeMode;
import dev.krypton.lz;
import dev.krypton.module.Category;
import dev.krypton.module.Module;
import dev.krypton.pgj;
import dev.krypton.rq;
import dev.krypton.setting.BooleanSetting;
import dev.krypton.setting.NumberSetting;
import dev.krypton.setting.Setting;
import dev.krypton.util.ColorValue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;

public class HoleESP extends Module {

   public NumberSetting minDepth = new NumberSetting("Min Depth", 1.0, 20.0, 4.0, 1.0);
   public BooleanSetting holes1x1 = new BooleanSetting("1x1 Holes", true);
   public BooleanSetting holes3x1 = new BooleanSetting("3x1 Holes", true);
   public NumberSetting alpha = new NumberSetting("Alpha", 1.0, 255.0, 120.0, 1.0);

   public Set<lz> singleHoles = ConcurrentHashMap.newKeySet();
   public Set<lz> longHoles = ConcurrentHashMap.newKeySet();
   public Set<ChunkPos> scannedChunks = ConcurrentHashMap.newKeySet();
   public ExecutorService executor;

   public HoleESP() {
      super("Hole ESP", "Shows holes to check if someone has already found the base", -1, Category.BASE_FINDING);
      this.addSettings(new Setting[]{this.minDepth, this.holes1x1, this.holes3x1, this.alpha});
   }

   @Override
   public void onEnable() {
      this.executor = Executors.newSingleThreadExecutor();
      this.singleHoles.clear();
      this.longHoles.clear();
      this.scannedChunks.clear();

      if (this.lr.player != null && this.lr.world != null) {
         for (Object obj : rq.zo()) {
            WorldChunk chunk = (WorldChunk) obj;
            this.processChunkAsync(chunk);
         }
      }

      super.onEnable();
   }

   @Override
   public void onDisable() {
      if (this.executor != null && !this.executor.isShutdown()) {
         this.executor.shutdownNow();
      }

      this.singleHoles.clear();
      this.longHoles.clear();
      this.scannedChunks.clear();
      super.onDisable();
   }

   @Subscribe
   public void onGameJoin(GameJoinEvent event) {
      this.singleHoles.clear();
      this.longHoles.clear();
      this.scannedChunks.clear();
   }

   @Subscribe
   public void onChunkData(ChunkDataEvent event) {
      if (this.lr.world != null) {
         WorldChunk chunk = this.lr.world.getChunk(event.packet.getChunkX(), event.packet.getChunkZ());
         this.processChunkAsync(chunk);
      }
   }

   @Subscribe
   public void onRender(WorldRenderEvent event) {
      if (this.lr.world == null || this.lr.player == null) return;

      int alphaVal = this.alpha.getInt();
      ColorValue redColor = new ColorValue(255, 0, 0, alphaVal);
      ColorValue orangeColor = new ColorValue(255, 165, 0, alphaVal);

      int viewDistance = this.lr.options.getClampedViewDistance();
      int playerChunkX = this.lr.player.getBlockX() >> 4;
      int playerChunkZ = this.lr.player.getBlockZ() >> 4;

      if (this.holes1x1.getValue()) {
         for (lz hole : this.singleHoles) {
            int chunkX = hole.la >> 4;
            int chunkZ = hole.ioi >> 4;
            if (Math.abs(chunkX - playerChunkX) <= viewDistance && Math.abs(chunkZ - playerChunkZ) <= viewDistance) {
               event.renderer.vqo(hole.la, hole.mjo, hole.ioi, hole.la + 1, hole.ozg, hole.ioi + 1, redColor, redColor, ShapeMode.OUTLINE, 0);
            }
         }
      }

      if (this.holes3x1.getValue()) {
         for (lz hole : this.longHoles) {
            int chunkX = hole.la >> 4;
            int chunkZ = hole.ioi >> 4;
            if (Math.abs(chunkX - playerChunkX) <= viewDistance && Math.abs(chunkZ - playerChunkZ) <= viewDistance) {
               event.renderer.vqo(hole.la, hole.mjo, hole.ioi, hole.la + hole.od, hole.ozg, hole.ioi + hole.tbu, orangeColor, orangeColor, ShapeMode.OUTLINE, 0);
            }
         }
      }
   }

   public void processChunkAsync(WorldChunk chunk) {
      if (this.executor != null && !this.executor.isShutdown()) {
         this.executor.submit(() -> this.scanChunk(chunk));
      }
   }

   public void check1x1Holes(pgj blockAccessor, int x, int z, int minY, int maxY, int requiredDepth) {
      int currentDepth = 0;
      int startY = 0;

      for (int y = minY; y < maxY; y++) {
         if (this.is1x1AirSlot(blockAccessor, x, y, z)) {
            currentDepth++;
            if (startY == 0) {
               startY = y;
            }
         } else {
            if (currentDepth >= requiredDepth) {
               this.singleHoles.add(new lz(x, z, startY, startY + currentDepth, 1, 1));
            }
            currentDepth = 0;
            startY = 0;
         }
      }

      if (currentDepth >= requiredDepth) {
         this.singleHoles.add(new lz(x, z, startY, startY + currentDepth, 1, 1));
      }
   }

   public void check3x1HolesX(pgj blockAccessor, int x, int z, int minY, int maxY, int requiredDepth) {
      int currentDepth = 0;
      int startY = 0;

      for (int y = minY; y < maxY; y++) {
         if (this.is3x1AirSlotX(blockAccessor, x, y, z)) {
            currentDepth++;
            if (startY == 0) {
               startY = y;
            }
         } else {
            if (currentDepth >= requiredDepth) {
               this.longHoles.add(new lz(x, z, startY, startY + currentDepth, 3, 1));
            }
            currentDepth = 0;
            startY = 0;
         }
      }

      if (currentDepth >= requiredDepth) {
         this.longHoles.add(new lz(x, z, startY, startY + currentDepth, 3, 1));
      }
   }

   public void check3x1HolesZ(pgj blockAccessor, int x, int z, int minY, int maxY, int requiredDepth) {
      int currentDepth = 0;
      int startY = 0;

      for (int y = minY; y < maxY; y++) {
         if (this.is3x1AirSlotZ(blockAccessor, x, y, z)) {
            currentDepth++;
            if (startY == 0) {
               startY = y;
            }
         } else {
            if (currentDepth >= requiredDepth) {
               this.longHoles.add(new lz(x, z, startY, startY + currentDepth, 1, 3));
            }
            currentDepth = 0;
            startY = 0;
         }
      }

      if (currentDepth >= requiredDepth) {
         this.longHoles.add(new lz(x, z, startY, startY + currentDepth, 1, 3));
      }
   }

   public boolean isPassable(BlockState state) {
      return state.getCollisionShape(this.lr.world, BlockPos.ORIGIN).isEmpty();
   }

   public boolean is1x1AirSlot(pgj blockAccessor, int x, int y, int z) {
      BlockState state = blockAccessor.vq(x, y, z);
      if (this.isPassable(state)) {
         return !this.isPassable(blockAccessor.vq(x - 1, y, z))
             && !this.isPassable(blockAccessor.vq(x + 1, y, z))
             && !this.isPassable(blockAccessor.vq(x, y, z - 1))
             && !this.isPassable(blockAccessor.vq(x, y, z + 1));
      }
      return false;
   }

   public boolean is3x1AirSlotX(pgj blockAccessor, int x, int y, int z) {
      if (!this.isPassable(blockAccessor.vq(x, y, z))) return false;
      if (!this.isPassable(blockAccessor.vq(x + 1, y, z))) return false;
      if (!this.isPassable(blockAccessor.vq(x + 2, y, z))) return false;

      if (this.isPassable(blockAccessor.vq(x - 1, y, z))) return false;
      if (this.isPassable(blockAccessor.vq(x + 3, y, z))) return false;

      if (this.isPassable(blockAccessor.vq(x, y, z - 1))) return false;
      if (this.isPassable(blockAccessor.vq(x, y, z + 1))) return false;
      if (this.isPassable(blockAccessor.vq(x + 1, y, z - 1))) return false;
      if (this.isPassable(blockAccessor.vq(x + 1, y, z + 1))) return false;
      if (this.isPassable(blockAccessor.vq(x + 2, y, z - 1))) return false;
      return !this.isPassable(blockAccessor.vq(x + 2, y, z + 1));
   }

   public boolean is3x1AirSlotZ(pgj blockAccessor, int x, int y, int z) {
      if (!this.isPassable(blockAccessor.vq(x, y, z))) return false;
      if (!this.isPassable(blockAccessor.vq(x, y, z + 1))) return false;
      if (!this.isPassable(blockAccessor.vq(x, y, z + 2))) return false;

      if (this.isPassable(blockAccessor.vq(x, y, z - 1))) return false;
      if (this.isPassable(blockAccessor.vq(x, y, z + 3))) return false;

      if (this.isPassable(blockAccessor.vq(x - 1, y, z))) return false;
      if (this.isPassable(blockAccessor.vq(x + 1, y, z))) return false;
      if (this.isPassable(blockAccessor.vq(x - 1, y, z + 1))) return false;
      if (this.isPassable(blockAccessor.vq(x + 1, y, z + 1))) return false;
      if (this.isPassable(blockAccessor.vq(x - 1, y, z + 2))) return false;
      return !this.isPassable(blockAccessor.vq(x + 1, y, z + 2));
   }

   public void scanChunk(WorldChunk chunk) {
      if (this.lr.world == null || !this.isEnabled()) return;

      ChunkPos chunkPos = chunk.getPos();
      if (!this.scannedChunks.contains(chunkPos)) {
         this.scannedChunks.add(chunkPos);

         int startX = chunkPos.getStartX();
         int startZ = chunkPos.getStartZ();
         int bottomY = this.lr.world.getBottomY();
         int height = this.lr.world.getHeight();
         pgj blockAccessor = new pgj();
         int depth = this.minDepth.getInt();

         for (int x = startX; x < startX + 16; x++) {
            for (int z = startZ; z < startZ + 16; z++) {
               if (this.holes1x1.getValue()) {
                  this.check1x1Holes(blockAccessor, x, z, bottomY, height, depth);
               }
               if (this.holes3x1.getValue()) {
                  this.check3x1HolesX(blockAccessor, x, z, bottomY, height, depth);
                  this.check3x1HolesZ(blockAccessor, x, z, bottomY, height, depth);
               }
            }
         }
      }
   }
}