package dev.krypton.module.KrModules;

public enum AuctionMode {
   API,
   MANUAL
}