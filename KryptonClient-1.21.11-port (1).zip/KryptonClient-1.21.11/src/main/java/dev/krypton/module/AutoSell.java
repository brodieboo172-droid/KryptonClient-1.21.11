package dev.krypton.module.KrModules;

import dev.krypton.event.Subscribe;
import dev.krypton.event.WorldTickEvent;
import dev.krypton.h;
import dev.krypton.module.Category;
import dev.krypton.module.Module;
import dev.krypton.setting.BooleanSetting;
import dev.krypton.setting.ItemSetting;
import dev.krypton.setting.ModeSetting;
import dev.krypton.setting.NumberSetting;
import dev.krypton.setting.Setting;
import dev.krypton.setting.StringSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.item.Item;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

public class AutoSell extends Module {

   public ModeSetting mode;
   public ItemSetting sellItem;
   public StringSetting targetPlayer;
   public NumberSetting delay;
   public BooleanSetting quickDeliver;
   public int delayTicks;
   public boolean sellingActive;

   public AutoSell() {
      super("Auto Sell", "Automatically Sells Chosen Item", -1, Category.DONUT);

      this.mode = new ModeSetting("Mode", AutoSellMode.SELL, AutoSellMode.class);
      this.sellItem = new ItemSetting("Item", Items.SEA_PICKLE);
      this.targetPlayer = new StringSetting("Who To Sell", "");
      this.delay = (new NumberSetting("Delay", 0.0, 20.0, 2.0, 1.0)).setDescription("What should be delay in ticks");
      this.quickDeliver = (new BooleanSetting("Quick Deliver", true)).setDescription("Move all matching items at once using vanilla shift-double-click pattern");

      this.addSettings(new Setting[]{this.mode, this.sellItem, this.targetPlayer, this.delay, this.quickDeliver});
   }

   @Override
   public void onEnable() {
      super.onEnable();
      this.delayTicks = 0;
   }

   @Override
   public void onDisable() {
      super.onDisable();
   }

   @Subscribe
   public void onTick(WorldTickEvent event) {
      if (this.mc.player == null) return;

      GenericContainerScreenHandler container = this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler ? (GenericContainerScreenHandler) this.mc.player.currentScreenHandler : null;

      if (this.delayTicks > 0) {
         this.delayTicks--;
         return;
      }

      if (((AutoSellMode) this.mode.getValue()).equals(AutoSellMode.SELL)) {
         if (this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler && container.getRows() == 4) {
            if (h.kv(Items.AIR) > 0) {
               Item targetItem = this.sellItem.getValue();
               int syncId = this.mc.player.currentScreenHandler.syncId;
               List<Integer> matchingSlots = new ArrayList<>();
               ItemStack referenceStack = ItemStack.EMPTY;

               for (int slot = 36; slot <= 71; slot++) {
                  ItemStack currentStack = this.mc.player.currentScreenHandler.getStacks().get(slot);
                  if (!currentStack.isEmpty() && currentStack.getItem() == targetItem) {
                     if (referenceStack.isEmpty()) {
                        referenceStack = currentStack;
                        matchingSlots.add(slot);
                     } else if (ItemStack.areItemsAndComponentsEqual(referenceStack, currentStack)) {
                        matchingSlots.add(slot);
                     }
                  }
               }

               if (matchingSlots.isEmpty()) {
                  this.mc.player.closeHandledScreen();
                  this.delayTicks = 10;
                  return;
               }

               if (this.quickDeliver.getValue() && matchingSlots.size() > 1) {
                  int firstSlot = matchingSlots.get(0);
                  this.mc.interactionManager.clickSlot(syncId, firstSlot, 0, SlotActionType.PICKUP, this.mc.player);
                  for (int i = 1; i < matchingSlots.size(); i++) {
                     this.mc.interactionManager.clickSlot(syncId, matchingSlots.get(i), 0, SlotActionType.QUICK_MOVE, this.mc.player);
                  }
                  this.mc.interactionManager.clickSlot(syncId, firstSlot, 0, SlotActionType.PICKUP, this.mc.player);
                  this.mc.interactionManager.clickSlot(syncId, firstSlot, 0, SlotActionType.QUICK_MOVE, this.mc.player);
               } else {
                  for (int slotIndex : matchingSlots) {
                     this.mc.interactionManager.clickSlot(syncId, slotIndex, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                     this.delayTicks = this.delay.getInt();
                     if (this.delay.getInt() != 0) return;
                  }
               }
               this.delayTicks = 5;
               return;
            } else {
               this.mc.player.closeHandledScreen();
               this.delayTicks = 10;
               return;
            }
         } else if (container != null && container.getRows() == 3) {
            this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, 15, 1, SlotActionType.QUICK_MOVE, this.mc.player);
            this.delayTicks = 10;
            this.sellingActive = true;
            return;
         } else if (container != null && container.getRows() == 6) {
            ItemStack sortItem = container.getSlot(47).getStack();
            if (sortItem.isOf(Items.AIR)) {
               this.delayTicks = 2;
               this.mc.player.closeHandledScreen();
               return;
            }

            TooltipContext context = TooltipContext.create(this.mc.world);
            for (Text tooltipLine : sortItem.getTooltip(context, this.mc.player, TooltipType.BASIC)) {
               String lineText = tooltipLine.toString();
               if (lineText.contains("Most Money Per Item") && (tooltipLine.getStyle().toString().contains("white") || lineText.contains("white"))) {
                  this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, 47, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                  this.delayTicks = 5;
                  return;
               }
            }

            for (int slot = 0; slot < 44; slot++) {
               if (container.getSlot(slot).getStack().isOf(this.sellItem.getValue())) {
                  this.mc.interactionManager.clickSlot(this.mc.player.currentScreenHandler.syncId, slot, 1, SlotActionType.QUICK_MOVE, this.mc.player);
                  this.delayTicks = 10;
                  return;
               }
            }
            this.delayTicks = 40;
            this.mc.player.closeHandledScreen();
            return;
         } else {
            ClientPlayNetworkHandler networkHandler = this.mc.getNetworkHandler();
            if (networkHandler != null) {
               networkHandler.sendChatCommand("sell");
            }
            this.delayTicks = 20;
            return;
         }
      } else {
         String itemName = this.getFormattedItemName();
         if (itemName.equals("Air")) {
            this.delayTicks = 20;
         } else {
            if (!this.targetPlayer.getValue().isEmpty()) {
               itemName = itemName + " " + this.targetPlayer.getValue();
            }
            ClientPlayNetworkHandler networkHandler = this.mc.getNetworkHandler();
            if (networkHandler != null) {
               networkHandler.sendChatCommand("order " + itemName);
            }
            this.delayTicks = 20;
         }
      }
   }

   public String getFormattedItemName() {
      Item item = this.sellItem.getValue();
      return item.equals(Items.BONE) ? "Bones" : item.getName().getString();
   }
}