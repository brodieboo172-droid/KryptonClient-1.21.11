package dev.krypton.module.KrModules;

public enum SuspiciousEntityType {
   WANDERING_TRADER,
   VILLAGER,
   ZOMBIE_VILLAGER,
   LLAMA,
   PILLAGER;
}