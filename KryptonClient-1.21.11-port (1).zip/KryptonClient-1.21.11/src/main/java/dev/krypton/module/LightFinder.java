package dev.krypton.module.KrModules;
import dev.krypton.event.Subscribe; import dev.krypton.module.Category; import dev.krypton.module.Module; import dev.krypton.event.WorldRenderEvent; import dev.krypton.gui.render.ShapeMode; import dev.krypton.util.ColorValue;
import net.minecraft.util.math.BlockPos; import net.minecraft.world.LightType;
public class LightFinder extends Module {
 public LightFinder(){super("Light Finder","Renders non-zero block-light cells below Y=0 for base finding",-1,Category.BASE_FINDING);}
 @Subscribe public void onRender(WorldRenderEvent event){
  if(lr.world==null||lr.player==null)return;
  int r=Math.min(lr.options.getClampedViewDistance(),8), cx=lr.player.getBlockX()>>4, cz=lr.player.getBlockZ()>>4;
  int minY=Math.max(lr.world.getBottomY(),-64), maxY=Math.min(lr.world.getTopY(),0);
  for(int x=(cx-r)*16;x<(cx+r+1)*16;x+=2) for(int z=(cz-r)*16;z<(cz+r+1)*16;z+=2) for(int y=minY;y<maxY;y+=2){
   int light=lr.world.getLightLevel(LightType.BLOCK,new BlockPos(x,y,z));
   if(light>0){float b=light/15f;ColorValue c=new ColorValue(b,b,.2f,.3f);event.renderer.vqo(x,y,z,x+1,y+1,z+1,c,c,ShapeMode.OUTLINE,0);}
  }
 }
}
