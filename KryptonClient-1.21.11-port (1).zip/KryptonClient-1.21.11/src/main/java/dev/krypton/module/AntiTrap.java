package dev.krypton.module.KrModules;
import dev.krypton.event.Subscribe; import dev.krypton.module.Category; import dev.krypton.module.Module;
import dev.krypton.event.WorldTickEvent;
import dev.krypton.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.Entity.RemovalReason;
import net.minecraft.entity.EntityType;
public class AntiTrap extends Module {
 public AntiTrap(){super("Anti Trap","Removes armor stands and chest minecarts used as traps",-1,Category.DONUT);addSettings(new Setting[0]);}
 @Override public void onEnable(){super.onEnable();clearTrapEntities();}
 @Subscribe public void onTick(WorldTickEvent e){clearTrapEntities();}
 public void clearTrapEntities(){if(mc.world==null)return;for(Entity e:mc.world.getEntities())if(isTrapEntity(e.getType()))removeEntity(e);}
 public boolean isTrapEntity(EntityType<?> t){return t==EntityType.ARMOR_STAND||t==EntityType.CHEST_MINECART;}
 public static void removeEntity(Entity e){if(!e.isRemoved())e.remove(RemovalReason.DISCARDED);}
}
