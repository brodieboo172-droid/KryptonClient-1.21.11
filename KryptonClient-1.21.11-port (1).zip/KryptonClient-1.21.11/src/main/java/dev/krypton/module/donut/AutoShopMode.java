package dev.krypton.module.donut; public enum AutoShopMode { HXT, MNS, BTF }
