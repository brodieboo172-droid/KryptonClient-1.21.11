package dev.krypton.module;
public enum Category { BASE_FINDING, DONUT }
