package dev.krypton.integration.discord;
import dev.krypton.util.ColorValue; import java.util.*;
public final class DiscordEmbed { String title,thumb,footerText,footerIcon; int color=0xffffff; final List<String[]> fields=new ArrayList<>();
 public void setTitle(String s){title=s;} public void setThumbnail(String s){thumb=s;} public void setColor(ColorValue c){color=(c.r<<16)|(c.g<<8)|c.b;} public void setFooter(String t,String i){footerText=t;footerIcon=i;} public void addField(String n,String v,boolean inline){fields.add(new String[]{n,v,Boolean.toString(inline)});} }
