# Krypton Client — Minecraft 1.21.11

Fabric client port based on the supplied Krypton Java module sources.

## Build
Use Java 21 and a current Gradle installation:

    gradle build

The built mod will be in `build/libs/`.

## Controls
The modules are bound to F6 onward in this order:

1. Anti Trap
2. Auction Sniper
3. Auto Sell
4. Auto Shop
5. Hole ESP
6. Light Finder
7. Seed Chunk Finder
8. Sus Chunk Finder
9. Suspicious ESP

The original sources depended on a private Krypton framework. This project supplies a small Fabric-compatible replacement for its module/settings/event/rendering framework.

## Notes
- The supplied sources are heavily tied to the Donut server commands/GUI layout, so those automation modules intentionally retain those commands and slot assumptions.
- Anti Trap is implemented as a client-side removal pass because a normal Fabric client event cannot cancel the server's entity-spawn packet after it has been decoded.
- Light Finder was rewritten to use the public 1.21.11 lighting API instead of the original private mixin accessors.
